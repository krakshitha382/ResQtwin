# ResQ Twin backend (local hackathon prototype)

This backend adds real staff authentication, role-based API access, persistent emergency records and an administrator staff directory. It uses a JSON file database (`backend/data/resqtwin.json`) so it runs without a database server or native SQLite build tools. The data survives browser refreshes and backend restarts on the same machine. For multiple computers, host this API on a reachable server and configure the frontend API URL; do not use this local setup as a production hospital system.

## 1. Install and start backend (Windows PowerShell)
```powershell
cd backend
Copy-Item .env.example .env
# Edit .env and set JWT_SECRET to a long random secret (32+ characters)
npm install
npm run seed
npm run dev
```
Backend health check: http://localhost:4000/api/health

## 2. Start frontend in a second terminal
From the project root:
```powershell
npm install
npm run dev
```
Optional root `.env.local`:
```env
VITE_API_URL=http://localhost:4000/api
```

## 3. Seeded demonstration accounts
Use email OR staff ID with the password below. The selected role is taken from the account record; the login screen does not let users choose or impersonate another role.

| Role | Name | Email | Staff ID | Demo password |
|---|---|---|---|---|
| Administrator | ResQ Administrator | admin@resqtwin.demo | ADM001 | Admin@123 |
| Doctor | Dr. Raj Menon | raj.doctor@resqtwin.demo | DOC001 | Doctor@123 |
| Doctor | Dr. Asha Rao | asha.doctor@resqtwin.demo | DOC002 | Doctor@123 |
| Doctor | Dr. Kiran Shah | kiran.doctor@resqtwin.demo | DOC003 | Doctor@123 |
| Nurse | Ananya Rao | ananya.nurse@resqtwin.demo | NUR001 | Nurse@123 |
| Nurse | Priyanka Das | priyanka.nurse@resqtwin.demo | NUR002 | Nurse@123 |
| Receptionist | Meera Iyer | meera.reception@resqtwin.demo | REC001 | Reception@123 |
| Security | Arun Kumar | arun.security@resqtwin.demo | SEC001 | Security@123 |

All demo passwords are for local demonstration only. Change them before sharing or deploying. The seed command resets these demo account passwords to the listed values.

## 4. Add staff
Sign in as Administrator. The API supports `POST /api/staff` with `{staffId,name,email,role,department,password}`. Only an authenticated Administrator can create accounts. Email and staff ID must be unique; passwords are stored as bcrypt hashes.

## 5. Data and limitations
- Staff accounts and emergency records are persisted in `backend/data/resqtwin.json`.
- JWT sessions expire after 12 hours. API endpoints enforce roles server-side.
- `GET /api/alerts` scopes records to the signed-in role. Administrator can view all; doctors see alerts routed to them; nurses see alerts they raised.
- The frontend now saves emergency snapshots to the backend and refreshes the signed-in role's visible emergency records every 5 seconds. This provides basic cross-device synchronization when all devices point to the same reachable backend. The existing browser-side emergency workflow remains a demo implementation; server-authoritative assignment, audit enforcement and escalation still need further hardening before production.
- No SMS, WhatsApp, push notification, clinical decision support or patient-care integration is provided.
- This is a synthetic-data hackathon prototype, not clinically validated software.

## Environment variables
`PORT`, `JWT_SECRET`, `CLIENT_ORIGIN`, `DATABASE_FILE`; frontend: `VITE_API_URL`.
