import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const file = path.resolve(process.cwd(), process.env.DATABASE_FILE || './data/resqtwin.json');
const defaults = { users: [], alerts: [], audit: [], tasks: [], departments: [], rooms: [] };
export function loadDb() { try { return { ...defaults, ...JSON.parse(fs.readFileSync(file, 'utf8')) }; } catch { return structuredClone(defaults); } }
export function saveDb(db) { fs.mkdirSync(path.dirname(file), { recursive: true }); const tmp = `${file}.tmp`; fs.writeFileSync(tmp, JSON.stringify(db, null, 2)); fs.renameSync(tmp, file); }
export function updateDb(fn) { const db = loadDb(); const result = fn(db); saveDb(db); return result; }
