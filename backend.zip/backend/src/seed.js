import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { loadDb, saveDb } from './db.js';
const db = loadDb();
const demo = [
 { id:'DOC-001', staffId:'DOC001', name:'Dr. Raj Menon', email:'raj.doctor@resqtwin.demo', role:'Doctor', department:'Emergency', password:'Doctor@123' },
 { id:'DOC-002', staffId:'DOC002', name:'Dr. Asha Rao', email:'asha.doctor@resqtwin.demo', role:'Doctor', department:'Cardiology', password:'Doctor@123' },
 { id:'DOC-003', staffId:'DOC003', name:'Dr. Kiran Shah', email:'kiran.doctor@resqtwin.demo', role:'Doctor', department:'Neurology', password:'Doctor@123' },
 { id:'NUR-001', staffId:'NUR001', name:'Ananya Rao', email:'ananya.nurse@resqtwin.demo', role:'Nurse', department:'Emergency', password:'Nurse@123' },
 { id:'NUR-002', staffId:'NUR002', name:'Priyanka Das', email:'priyanka.nurse@resqtwin.demo', role:'Nurse', department:'ICU', password:'Nurse@123' },
 { id:'REC-001', staffId:'REC001', name:'Meera Iyer', email:'meera.reception@resqtwin.demo', role:'Receptionist', department:'Front Desk', password:'Reception@123' },
 { id:'SEC-001', staffId:'SEC001', name:'Arun Kumar', email:'arun.security@resqtwin.demo', role:'Security', department:'Security', password:'Security@123' },
 { id:'ADM-001', staffId:'ADM001', name:'ResQ Administrator', email:'admin@resqtwin.demo', role:'Administrator', department:'Administration', password:'Admin@123' }
];
for (const person of demo) {
 const existing = db.users.find(u => u.staffId === person.staffId);
 const passwordHash = await bcrypt.hash(person.password, 12);
 const record = { ...person, passwordHash, active:true }; delete record.password;
 if (existing) Object.assign(existing, record); else db.users.push(record);
}
if (!db.departments.length) db.departments = [{id:'ER',name:'Emergency',floor:'2',rooms:['204','205'],doctorId:'DOC-001'},{id:'CARD',name:'Cardiology',floor:'2',rooms:['201','202'],doctorId:'DOC-002'},{id:'NEURO',name:'Neurology',floor:'3',rooms:['301','302'],doctorId:'DOC-003'}];
saveDb(db);
console.log(`Seeded ${demo.length} demo staff accounts. Change all demo passwords before any public deployment.`);
